package com.josea.u23.maven;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MavenApplicationTests {

	@Test
	void contextLoads() {
	}

}
